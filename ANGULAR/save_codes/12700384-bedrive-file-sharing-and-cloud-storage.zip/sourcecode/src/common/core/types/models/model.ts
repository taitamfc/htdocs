export interface Model {
    id?: number;
    name?: string;
}
