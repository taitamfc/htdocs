export interface Localization {
    id: number;
    name: string;
    language: string;
    created_at?: string;
    updated_at?: string;
}
