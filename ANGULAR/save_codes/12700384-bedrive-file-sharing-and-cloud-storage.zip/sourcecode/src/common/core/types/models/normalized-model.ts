export interface NormalizedModel {
  id: number;
  name: string;
  image: string;
}
