import { InjectionToken } from '@angular/core';

export const AVAILABLE_CONTEXT_MENUS = new InjectionToken<any>('AVAILABLE_CONTEXT_MENUS');
