import { InjectionToken } from '@angular/core';

export const CONTEXT_MENU_DATA = new InjectionToken<{ [key: string]: any }>('CONTEXT_MENU_DATA');
