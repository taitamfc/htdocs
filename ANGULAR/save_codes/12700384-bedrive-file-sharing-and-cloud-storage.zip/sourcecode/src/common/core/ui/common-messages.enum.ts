export enum CommonMessages {
    NoPermissions = 'You don\'t have required permissions to do that.',
}
