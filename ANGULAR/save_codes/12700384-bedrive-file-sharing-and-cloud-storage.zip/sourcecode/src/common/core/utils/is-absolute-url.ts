export function isAbsoluteUrl(url: string): boolean {
    if ( ! url) return false;

    // Don't match Windows paths `c:\`
    if (/^[a-z]:\\/.test(url)) {
        return false;
    }

    // Scheme: https://tools.ietf.org/html/rfc3986#section-3.1
    // Absolute URL: https://tools.ietf.org/html/rfc3986#section-4.3
    return /^[a-z][a-z\d+\-.]*:/.test(url);
}
