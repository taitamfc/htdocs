export const spaceUnits = [
    'bytes',
    'KB',
    'MB',
    'GB',
    'TB',
    'PB'
];
