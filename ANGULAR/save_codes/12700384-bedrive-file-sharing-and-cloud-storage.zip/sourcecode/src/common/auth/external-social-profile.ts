export interface ExternalSocialProfile {
    id: number|string;
    email: string;
    avatar: string;
    name: string;
    profileUrl: string;
}
