export type DrivePageType = 'recent'|'trash'|'starred'|'folder'|'shares'|'search'|'workspaces';
