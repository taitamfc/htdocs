export interface UserSpaceUsage {
    used: number;
    available: number;
}