export enum FOLDERS_API_ROUTES {
    GET_ALL = 'drive/folders',
    CREATE = 'drive/folders',
}
