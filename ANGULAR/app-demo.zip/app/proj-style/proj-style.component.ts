import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proj-style',
  templateUrl: './proj-style.component.html',
  styleUrls: ['./proj-style.component.css']
})
export class ProjStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  your_text:string = 'Hello !';
  isCustom:boolean = false;

  colors : string[] = [
  	'Blue',
  	'Red',
  	'Custom',
  ];

  backgroundColor = 'blue';
  color = 'white';

  changeStyle( event:any ){
  	if( event.target.value == 'Custom' ){
  		this.isCustom = true;
  	}else{
  		this.isCustom = false;
  	}
  }
  setBgColor( event:any ){
  	this.backgroundColor = event.target.value;
  }
  setColor( event:any ){
  	this.color = event.target.value;
  }

  setStyles(): any{
  	return {
  		'background-color' : this.backgroundColor,
  		'color' : this.color,
  	}
  }

  

}
