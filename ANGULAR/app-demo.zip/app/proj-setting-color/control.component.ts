import { Component,Input ,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-control',
  templateUrl: './control.component.html',
})
export class ControlComponent {
	ComponentTitle: string = 'Control Component';
	@Input('mcolor') control_color?: string;
	@Output('selectColor') selectColor = new EventEmitter<string>();

	changeColor( value:string ){
		console.log('ControlComponent changeColor: '+value );
		this.selectColor.emit(value);
	}
}
