import { Component,Input} from '@angular/core';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
})
export class PreviewComponent {
	ComponentTitle: string = 'Preview Component';
	@Input('color') preview_color?: string;
}
