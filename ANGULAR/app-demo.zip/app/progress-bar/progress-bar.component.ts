import { Component, OnInit, Input,OnChanges } from "@angular/core";

@Component({
  selector: 'app-progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.css']
})
export class ProgressBarComponent implements OnInit,OnChanges {
  @Input() progress = 15;
  @Input() backgroundColor = '#9e9e9e';
  @Input() progressColor = '#2e8b57';
  constructor() { }

  ngOnInit(): void {}
  ngOnChanges(): void {}
  
  
}
